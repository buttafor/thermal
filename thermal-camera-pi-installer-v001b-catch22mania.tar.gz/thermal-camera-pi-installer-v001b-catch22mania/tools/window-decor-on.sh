#!/bin/bash

# IR Thermal Cameras for Drones, FPV & RC 
#
# libseek-thermal, v4l2, mlx90460 install script for Raspbian 64 bit
#
# (c) catch22mania 04/2023 https://www.youtube.com/@catch22mania

# enable decor (Openbox)

perl -0777 -i -pe 's/<application class="\*">\n<decor>no<\/decor>\n<\/application>\n<\/applications>\n<\/openbox_config>//g' ~/.config/openbox/rc.xml
perl -0777 -i -pe 's/<\/applications>\n\n<\/openbox_config>//g' ~/.config/openbox/rc.xml

echo '</applications>' >> ~/.config/openbox/rc.xml
echo '' >> ~/.config/openbox/rc.xml
echo '</openbox_config>' >> ~/.config/openbox/rc.xml

exit 0
