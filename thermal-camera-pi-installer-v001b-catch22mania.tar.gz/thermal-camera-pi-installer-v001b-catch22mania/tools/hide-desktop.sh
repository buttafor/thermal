#!/bin/bash

# IR Thermal Cameras for Drones, FPV & RC 
#
# libseek-thermal, v4l2, mlx90460 install script for Raspbian 64 bit
#
# (c) catch22mania 04/2023 https://www.youtube.com/@catch22mania

# hide panel etc. - start menu still available (icon hidden)

rm ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
echo '[*]' >> ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
echo "wallpaper=/home/`whoami`/install/additional-stuff/pics/black.png" >> ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
echo 'desktop_bg=#000000' >> ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
echo 'show_trash=0' >> ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf

rm /home/`whoami`/.config/lxpanel/LXDE-pi/panels/panels

echo 'Global {
  edge=top
  align=left
  margin=0
  widthtype=pixel
  width=1
  height=20
  transparent=0
  tintcolor=#000000
  alpha=0
  autohide=0
  heightwhenhidden=2
  setdocktype=1
  setpartialstrut=1
  usefontcolor=0
  fontsize=12
  fontcolor=#ffffff
  usefontsize=0
  background=0
  backgroundfile=/usr/share/lxpanel/images/background.png
  iconsize=20
  monitor=0
  point_at_menu=0
  notifications=0
}
Plugin {
  type=smenu
  Config {
    padding=1
    image=start-here
    system {
    }
    separator {
    }
    item {
      image=system-run
      command=run
    }
    separator {
    }
    item {
      image=system-shutdown
      command=logout
    }
    fixed=0
  }
}
' >> /home/`whoami`/.config/lxpanel/LXDE-pi/panels/panels
