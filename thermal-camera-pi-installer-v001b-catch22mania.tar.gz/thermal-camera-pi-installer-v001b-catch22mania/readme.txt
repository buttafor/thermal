# IR Thermal Cameras for Drones, FPV & RC 
#
# libseek-thermal, v4l2, mlx90460 install script for Raspbian 64 bit
#
# (c) catch22mania 04/2023 https://www.youtube.com/@catch22mania

Seek Compact & Compact Pro, InfiRay P2 Pro, MLX90640 install script


checkout the tutorial video: https://youtu.be/JYp3dDWWEJ4 


paths (scripts, binaries and dev stuff):


libseek-thermal binaries -> ~/libseek-thermal-master/build/examples/

libseek-thermal dev stuff -> ~/libseek-thermal-master/

MLX90640 scripts & dev stuff -> ~/mlx90640

examples Seek -> ~/starter.sh.seek.examples

examples InfiRay -> ~/starter.sh.infiray.examples

autostart script -> ~/starter.sh

tools (hide desktop, -window decor) -> ~/install/tools



This is just a quick hack. Goal is a thermal camera which already supports composite out (576i, PAL, 4:3) by adding an additional mcu or using the onboard mcu. It should add less than $20 to the thermal camera. Any inexpensive FPV camera ($10+) supports composite out.



Seek Compact:

libseek-thermal: https://github.com/OpenThermal/libseek-thermal

FPV Thermal Cameras - Seek Compact Pro - quick test flight: https://youtu.be/C35rru15i0k
FPV Thermal Cameras - Seek Compact -  quick test flight: https://youtu.be/MMFlseGx4XI

InfiRay P2 Pro:

The P2 Pro works with the Linux V4L2 driver like many web cams.
Mplayer: http://www.mplayerhq.hu/design7/news.html
webcamoid example with custom palettes: https://www.youtube.com/watch?v=-ka_QUD2r00

FPV Thermal Cameras - InfiRay P2 Pro - short test flight & crash test: https://youtu.be/2cKUCA-EBAo 

MLX90640:

https://habr.com/en/articles/441050/
https://tomshaffner.github.io/PiThermalCam/ 
https://makersportal.com/blog/2020/6/8/high-resolution-thermal-camera-with-raspberry-pi-and-mlx90640

FPV Thermal Cameras - MLX90640 - test flight:  https://youtu.be/JImprXh4hTI 


Seek Compact

206 x 156
36° FOV
9 fps
weight: 14.34 g 
Auto Emissivity
$200

Seek Compact Pro FF

320 x 240
32° FOV
15 fps ?
weight: 14.64 g
Adjustable Emissivity
$400

InfiRay P2 Pro (next part)

256 x 192
56° x 42.2° FOV
25 fps ?
weight: 9.38 g
$250 (incl. additional macro lens)

